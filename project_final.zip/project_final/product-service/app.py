from flask import Flask, render_template_string
from prometheus_client import Counter, generate_latest

app = Flask(__name__)

REQUEST_COUNT = Counter('item_service_requests_total', 'Total requests to Item Service')

items = [
    {"id": 1, "name": "Book", "title": "Python for Beginners", "description": "Intro to Python programming.", "status": "Available"},
    {"id": 2, "name": "Laptop", "title": "Dell Inspiron", "description": "15-inch laptop for coding.", "status": "Borrowed"}
]

HTML_TEMPLATE = """<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ title if title else "Service" }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
      body { background: linear-gradient(120deg,#f6f9ff,#eef6ff); }
      .card { border-radius: 1rem; box-shadow: 0 6px 18px rgba(20,40,80,0.08); }
      .brand { color: #0d6efd; font-weight:700; }
      .metrics-link { font-size:0.9rem; }
      .badge-status { font-weight:600; }
    </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg bg-white shadow-sm mb-4">
      <div class="container">
        <a class="navbar-brand brand" href="#">MyMicro</a>
        <div>
          <a class="btn btn-outline-primary btn-sm metrics-link" href="/metrics">/metrics</a>
        </div>
      </div>
    </nav>
    <div class="container">
      <div class="row g-3">
        {% if items %}
          {% for it in items %}
          <div class="col-md-6">
            <div class="card p-3">
              <h5>{{ it.name }} <small class="text-muted">#{{it.id}}</small></h5>
              <p class="mb-1">{{ it.title }}</p>
              <p class="text-muted">{{ it.description }}</p>
              <span class="badge bg-{{ 'success' if it.status=='Available' else 'warning' }} badge-status">{{ it.status }}</span>
            </div>
          </div>
          {% endfor %}
        {% elif users %}
          {% for u in users %}
          <div class="col-md-6">
            <div class="card p-3">
              <h5>{{ u.name }} <small class="text-muted">#{{u.id}}</small></h5>
              <p class="mb-1"><strong>Email:</strong> {{ u.email }}</p>
              <p class="mb-0"><strong>Phone:</strong> {{ u.phone }}</p>
            </div>
          </div>
          {% endfor %}
        {% else %}
          <p>No data</p>
        {% endif %}
      </div>
    </div>
  </body>
</html>
"""

@app.route("/items")
def get_items():
    REQUEST_COUNT.inc()
    return render_template_string(HTML_TEMPLATE, items=items)

@app.route("/metrics")
def metrics():
    return generate_latest(), 200, {'Content-Type': 'text/plain'}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001)
