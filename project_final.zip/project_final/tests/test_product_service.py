import pytest
from product_service import app as product_app

@pytest.fixture
def client():
    product_app.app.testing = True
    with product_app.app.test_client() as client:
        yield client

def test_items_page(client):
    rv = client.get('/items')
    assert rv.status_code == 200
    assert b'Book' in rv.data or b'Laptop' in rv.data

def test_metrics(client):
    rv = client.get('/metrics')
    assert rv.status_code == 200
    assert b'item_service_requests_total' in rv.data
