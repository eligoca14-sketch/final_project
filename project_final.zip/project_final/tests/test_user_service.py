import pytest
from user_service import app as user_app

@pytest.fixture
def client():
    user_app.app.testing = True
    with user_app.app.test_client() as client:
        yield client

def test_users_page(client):
    rv = client.get('/users')
    assert rv.status_code == 200
    assert b'Alice' in rv.data or b'Bob' in rv.data

def test_metrics(client):
    rv = client.get('/metrics')
    assert rv.status_code == 200
    assert b'user_service_requests_total' in rv.data
